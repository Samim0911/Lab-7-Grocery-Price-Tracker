import java.io.*;
import java.util.*;

public class GroceryTracker {

    public static void main(String[] args) throws IOException {

        // arrays to store data
        String[] names = new String[50];
        double[] prices = new double[50];

        // step 1: load data from file
        int count = loadGroceryData("groceries.txt", names, prices);

        // step 2: calculate average
        double avg = calculateAveragePrice(prices, count);

        // step 3: write report to file
        writeReport(names, prices, count, avg);

        System.out.println("Report created: grocery_report.txt");
    }

    public static int loadGroceryData(String filename, String[] names, double[] prices) throws IOException {

        File file = new File(filename);
        Scanner input = new Scanner(file);

        int count = 0;

        while (input.hasNextLine() && count < 50) {
            String line = input.nextLine();

            String[] parts = line.split(",");

            names[count] = parts[0];
            prices[count] = Double.parseDouble(parts[1]);

            count++;
        }

        input.close();
        return count;
    }

    public static double calculateAveragePrice(double[] prices, int count) {

        double sum = 0;

        for (int i = 0; i < count; i++) {
            sum += prices[i];
        }

        return sum / count;
    }
    
    public static void writeReport(String[] names, double[] prices, int count, double average) throws IOException {

        PrintWriter output = new PrintWriter("grocery_report.txt");

        output.println("Grocery Items Report");
        output.println("----------------------");

        for (int i = 0; i < count; i++) {
            output.printf("%s: $%.2f\n", names[i], prices[i]);
        }

        output.println();
        output.printf("Average Price: $%.2f\n", average);

        output.close();
    }
}